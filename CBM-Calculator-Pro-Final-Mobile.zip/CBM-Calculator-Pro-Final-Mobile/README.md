# CBM Calculator Pro — Mobile App

This is the production-ready mobile project based on the completed CBM Calculator Pro web app.

## Included
- CBM / CFT calculations
- Unit selection and quantity
- Sea / Air freight calculations
- Chargeable and volumetric weight
- Container planning
- Freight profiles and NBC Skye profile/rates already present in the source app
- Landed-cost calculation
- Customers, shipments, PDF/QR/share features from the source app
- English / Hausa
- Light / Dark mode
- Backup / Restore
- Offline/PWA support
- Android Capacitor wrapper
- GitHub Actions workflow that builds a debug APK remotely
- App icon and promotional artwork

## Build from a phone only
1. Create a GitHub repository named `cbm-calculator-pro`.
2. Upload all files/folders in this project.
3. Open the repository's **Actions** tab.
4. Run **Build Android APK**.
5. Open the completed workflow run and download the artifact named `cbm-calculator-pro-debug-apk`.
6. Extract the APK and install it on your Android phone.

The first APK is a debug build for testing. A signed release APK/AAB for Google Play requires a release keystore and Play Console setup.
